// Importing the add function from the Task1 module
const add = require('./Task1');

// Using the add function
const result = add(5,5);

console.log('The sum is:', result);
