const person = require('./Task2');

console.log(person.greet());

console.log(person.birthday());

console.log(`Updated age: ${person.age}`);