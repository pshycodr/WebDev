const Task3 = require('./Task3');

const sum = Task3.add(10,5);
const difference = Task3.subtract(10,5);
const product = Task3.multiply(10,5);
const quotient = Task3.divide(10,5);

console.log('Sum:', sum);
console.log('Difference:', difference);
console.log('Product:', product);
console.log('Quotient:', quotient);