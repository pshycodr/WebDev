// Create a module that exports a single function using default export. Import and use this function in another script.
function greet(name){
    return `Hello, ${name}!`;
}

export default greet;