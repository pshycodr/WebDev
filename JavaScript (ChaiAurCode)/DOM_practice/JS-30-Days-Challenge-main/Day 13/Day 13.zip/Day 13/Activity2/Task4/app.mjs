
// Import the default exported function from greet module
import greet from './Task4.mjs';

// Use the greet function
const message = greet('Aman');

console.log(message); // Output: Hello, Aman!
