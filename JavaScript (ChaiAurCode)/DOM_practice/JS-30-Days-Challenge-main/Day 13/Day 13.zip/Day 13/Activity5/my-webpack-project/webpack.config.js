// webpack.config.js

const path = require('path');

module.exports = {
    entry: './src/index.js', // Entry point for the bundle
    output: {
        filename: 'bundle.js', // Output file name
        path: path.resolve(__dirname, 'dist') // Output directory
    },
    mode: 'development' // Set mode to 'production' for optimized builds
};
