import { add } from "./add";
import { greet } from "./greet"

console.log(greet('Aman'));
console.log('Sum:', add(5,3));
